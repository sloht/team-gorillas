# Starter submission

Python 3.11+, standard library only.
The reproduction command loads the included baseline.json and predicts on /data/test.
Run: python predict.py --data /data --out /output/submission.csv
Training command: python run_starter.py --method pooled_recent --out outputs
Training settings, input hashes, and environment: training-run.json.
Forecast CSV is uploaded separately and is not included in this archive.
